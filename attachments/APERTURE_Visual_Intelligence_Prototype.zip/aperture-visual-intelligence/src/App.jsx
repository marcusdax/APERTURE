import React, { useMemo, useRef, useState } from "react";
import {
  Aperture, ArrowRight, ArrowUpRight, Bell, Check, ChevronDown, ChevronLeft,
  ChevronRight, CircleHelp, Clipboard, CloudUpload, Compass, Download,
  Eye, FileText, Focus, Grid2X2, Image as ImageIcon, Layers3, MapPin,
  Menu, MoreHorizontal, Plus, Scan, Search, Settings2, ShieldCheck,
  Sparkles, Target, WandSparkles, X, Zap
} from "lucide-react";

const stages = [
  { id: "discover", n: "01", label: "Discover", sub: "Set the scene" },
  { id: "reveal", n: "02", label: "Reveal", sub: "Read the evidence" },
  { id: "envision", n: "03", label: "Envision", sub: "Explore potential" },
  { id: "quantify", n: "04", label: "Quantify", sub: "Understand impact" },
  { id: "activate", n: "05", label: "Activate", sub: "Move with clarity" },
];

const findings = [
  { id: 1, title: "Primary frontage", type: "Visibility opportunity", confidence: "High", x: 22, y: 47, color: "cyan", detail: "The primary frontage is visually prominent and could support clearer tenant or brand identification." },
  { id: 2, title: "Parking approach", type: "Access consideration", confidence: "Medium", x: 72, y: 69, color: "gold", detail: "The approach path appears to be a useful point for wayfinding and access review." },
  { id: 3, title: "Roofline", type: "Condition review", confidence: "Medium", x: 62, y: 18, color: "violet", detail: "The roofline is a candidate for closer inspection. Image-only review cannot establish material condition." },
];

function SceneIllustration() {
  return <svg className="scene-svg" viewBox="0 0 1000 560" role="img" aria-label="Illustrative aerial view of a commercial property">
    <defs>
      <linearGradient id="ground" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#273746"/><stop offset="1" stopColor="#101d29"/></linearGradient>
      <linearGradient id="roof" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#9ba8ac"/><stop offset=".48" stopColor="#596d75"/><stop offset="1" stopColor="#334752"/></linearGradient>
      <linearGradient id="glass" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#b6c6c5"/><stop offset="1" stopColor="#3b6069"/></linearGradient>
      <pattern id="parking" width="48" height="30" patternUnits="userSpaceOnUse"><path d="M0 0V30" stroke="#9aadb0" strokeWidth="2" opacity=".55"/></pattern>
      <pattern id="grain" width="120" height="120" patternUnits="userSpaceOnUse"><circle cx="8" cy="10" r="1" fill="#fff" opacity=".13"/><circle cx="72" cy="55" r="1" fill="#fff" opacity=".1"/><circle cx="35" cy="97" r="1" fill="#fff" opacity=".1"/></pattern>
    </defs>
    <rect width="1000" height="560" fill="url(#ground)"/>
    <path d="M0 408L1000 286V560H0Z" fill="#172a32"/>
    <path d="M0 436L1000 313" stroke="#91a3a3" strokeWidth="3" opacity=".2"/>
    <path d="M0 458L1000 335" stroke="#91a3a3" strokeWidth="2" opacity=".16"/>
    <path d="M40 40L960 40L960 520L40 520Z" fill="none" stroke="#78919a" strokeWidth="1" opacity=".18"/>
    <path d="M88 90L705 44L900 174L278 231Z" fill="#2e414a" stroke="#a8b7b8" strokeWidth="2"/>
    <path d="M278 231L900 174L900 364L278 422Z" fill="url(#glass)" stroke="#b7c5c4" strokeWidth="2"/>
    <path d="M88 90L278 231L278 422L88 277Z" fill="#50646c" stroke="#b7c5c4" strokeWidth="2"/>
    <path d="M88 90L705 44L900 174L278 231Z" fill="url(#roof)" stroke="#c0cbca" strokeWidth="2"/>
    <path d="M140 105L705 63L835 151L278 203Z" fill="#63777c" opacity=".55"/>
    <path d="M278 250L900 194M278 286L900 230M278 324L900 268M278 362L900 306" stroke="#d1d9d5" strokeWidth="3" opacity=".6"/>
    <path d="M350 224V414M435 216V406M520 208V398M605 200V390M690 192V382M775 184V374M860 177V367" stroke="#243e49" strokeWidth="8" opacity=".8"/>
    <path d="M88 277L278 422L278 458L88 314Z" fill="#243943"/>
    <path d="M0 405L278 373L278 560L0 560Z" fill="#233943"/>
    <path d="M278 422L900 364L1000 415L1000 560L278 560Z" fill="#263b45"/>
    <path d="M305 455L955 394V550L305 550Z" fill="url(#parking)" opacity=".45"/>
    <path d="M30 350L225 332L225 375L30 393Z" fill="#71888a" opacity=".25"/>
    <g opacity=".85">
      <path d="M78 330l28-3 0 13-28 3zM140 324l29-3 0 13-29 3zM204 318l28-3 0 13-28 3z" fill="#c0c9c2"/>
      <path d="M360 474l40-4 0 16-40 4zM430 468l40-4 0 16-40 4zM500 462l40-4 0 16-40 4zM570 456l40-4 0 16-40 4zM640 450l40-4 0 16-40 4z" fill="#c5d0cb"/>
    </g>
    <g fill="#9caa8a" opacity=".65"><circle cx="60" cy="80" r="28"/><circle cx="34" cy="125" r="20"/><circle cx="946" cy="80" r="35"/><circle cx="950" cy="465" r="27"/><circle cx="40" cy="510" r="34"/></g>
    <rect width="1000" height="560" fill="url(#grain)"/>
  </svg>;
}

function Brand() {
  return <div className="brand"><div className="brand-mark"><Aperture size={20} strokeWidth={1.8}/></div><div><div className="brand-name">APERTURE<span>®</span></div><div className="brand-sub">VISUAL INTELLIGENCE</div></div></div>;
}

function App() {
  const [stage, setStage] = useState("discover");
  const [prompt, setPrompt] = useState("Identify visible property features, potential improvements, and opportunities worth investigating.");
  const [assetName, setAssetName] = useState("Three-tenant commercial center");
  const [location, setLocation] = useState("Fort Worth, Texas");
  const [fileUrl, setFileUrl] = useState("");
  const [fileName, setFileName] = useState("");
  const [selectedFinding, setSelectedFinding] = useState(1);
  const [compare, setCompare] = useState(54);
  const [showBrief, setShowBrief] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [toast, setToast] = useState("");
  const uploadRef = useRef(null);
  const currentIndex = stages.findIndex(s => s.id === stage);
  const finding = findings.find(f => f.id === selectedFinding) || findings[0];

  const notify = (message) => {
    setToast(message);
    window.clearTimeout(window.__apertureToast);
    window.__apertureToast = window.setTimeout(() => setToast(""), 2600);
  };

  const advance = () => setStage(stages[Math.min(currentIndex + 1, stages.length - 1)].id);
  const back = () => setStage(stages[Math.max(currentIndex - 1, 0)].id);

  const onFile = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (fileUrl) URL.revokeObjectURL(fileUrl);
    setFileUrl(URL.createObjectURL(file));
    setFileName(file.name);
    notify("Image added to this discovery.");
  };

  const imageStyle = fileUrl ? { backgroundImage: `url(${fileUrl})` } : {};
  const downloadBrief = () => {
    const content = `APERTURE INTELLIGENCE BRIEF\n\nAsset: ${assetName}\nLocation: ${location}\n\nDiscovery objective:\n${prompt}\n\nIllustrative findings (demo mode):\n${findings.map(f => `- ${f.title} — ${f.type} (${f.confidence} confidence): ${f.detail}`).join("\n")}\n\nNote: This prototype uses illustrative findings, not live AI analysis, verified measurements, inspection, valuation, or professional advice.`;
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "aperture-intelligence-brief.txt"; a.click();
    URL.revokeObjectURL(url);
    notify("Intelligence brief exported.");
  };

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
      <div className="sidebar-top"><Brand/><button className="icon-button mobile-close" onClick={() => setMobileNav(false)} aria-label="Close navigation"><X size={18}/></button></div>
      <div className="workspace-switch"><div className="workspace-avatar">A</div><div className="workspace-copy"><strong>APERTURE Studio</strong><span>Personal workspace</span></div><ChevronDown size={15}/></div>
      <div className="nav-label">WORKSPACE</div>
      <button className="nav-item active"><Compass size={17}/> Discovery workspace <span className="nav-live"/></button>
      <button className="nav-item" onClick={() => notify("Your saved intelligence will appear here.")}><Layers3 size={17}/> Intelligence library</button>
      <button className="nav-item" onClick={() => notify("Project tracking is coming into view.")}><Grid2X2 size={17}/> Projects</button>
      <div className="nav-label nav-label-spaced">YOUR WORK</div>
      <div className="recent-item"><span className="recent-dot cyan-dot"/> Three-tenant center <small>Today</small></div>
      <div className="recent-item"><span className="recent-dot gold-dot"/> Northside retail site <small>Oct 28</small></div>
      <button className="new-discovery" onClick={() => {setStage("discover");setMobileNav(false);}}><Plus size={16}/> New discovery</button>
      <div className="sidebar-bottom">
        <div className="signal-card"><div className="signal-icon"><Sparkles size={15}/></div><div><strong>See the bigger picture.</strong><p>Turn visual evidence into your next informed move.</p></div></div>
        <button className="nav-item"><CircleHelp size={17}/> Help & guidance</button>
        <button className="nav-item"><Settings2 size={17}/> Preferences</button>
        <div className="profile"><div className="profile-avatar">MM</div><div><strong>Workspace owner</strong><span>Visionary plan · Demo</span></div><MoreHorizontal size={18}/></div>
      </div>
    </aside>

    <main className="main">
      <header className="topbar">
        <div className="topbar-left"><button className="icon-button mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open navigation"><Menu size={19}/></button><div className="breadcrumb">Workspace <ChevronRight size={14}/> <strong>Discovery</strong></div></div>
        <div className="topbar-right"><div className="system-status"><span/> SYSTEM READY</div><button className="icon-button" aria-label="Notifications" onClick={() => notify("You're all caught up.")}><Bell size={17}/></button><div className="top-avatar">MM</div></div>
      </header>

      <div className="content">
        <div className="page-heading">
          <div><div className="eyebrow"><span className="eyebrow-line"/> INTELLIGENCE IN MOTION</div><h1>See beyond <em>the visible.</em></h1><p className="page-subtitle">Every image holds a bigger picture. Let's uncover what matters.</p></div>
          <div className="heading-actions"><span className="saved-state"><span/> Auto-saved</span><button className="outline-button" onClick={() => setShowBrief(true)}><FileText size={15}/> View brief</button></div>
        </div>

        <section className="journey" aria-label="Discovery progress">
          <div className="journey-track"><div className="journey-progress" style={{width: `${currentIndex * 25}%`}}/></div>
          {stages.map((s, i) => <button key={s.id} onClick={() => setStage(s.id)} className={`journey-step ${i === currentIndex ? "current" : ""} ${i < currentIndex ? "complete" : ""}`}>
            <span className="step-node">{i < currentIndex ? <Check size={13}/> : s.n}</span><span className="step-text"><strong>{s.label}</strong><small>{s.sub}</small></span>
          </button>)}
        </section>

        {stage === "discover" && <section className="stage-layout discover-layout">
          <div className="stage-main">
            <div className="section-kicker"><span>01</span> / DISCOVER</div>
            <h2>Start with what<br/>you <em>see.</em></h2>
            <p className="stage-description">Bring a place, an image, or a question. APERTURE will help structure the discovery around what you want to understand.</p>
            <div className="input-panel">
              <div className="panel-label"><ImageIcon size={15}/> YOUR VISUAL STARTING POINT</div>
              <div className={`upload-zone ${fileUrl ? "has-file" : ""}`} onClick={() => uploadRef.current?.click()} onDragOver={e => e.preventDefault()} onDrop={e => {e.preventDefault();const f=e.dataTransfer.files?.[0];if(f){setFileUrl(URL.createObjectURL(f));setFileName(f.name);}}}>
                {fileUrl ? <div className="uploaded-preview" style={imageStyle}/> : <div className="upload-graphic"><div className="upload-frame"><CloudUpload size={24}/><span className="upload-cross">+</span></div></div>}
                <div className="upload-copy"><strong>{fileUrl ? fileName : "Drop an image to begin"}</strong><span>{fileUrl ? "Image ready · Click to replace" : "or browse files from your device"}</span></div>
                <button className="browse-button" onClick={e => {e.stopPropagation();uploadRef.current?.click();}}>{fileUrl ? "Replace image" : "Browse images"}</button>
                <input ref={uploadRef} type="file" accept="image/*" hidden onChange={onFile}/>
              </div>
              <div className="field-grid">
                <label className="field"><span>ASSET / SUBJECT</span><input value={assetName} onChange={e => setAssetName(e.target.value)} placeholder="Name this discovery"/></label>
                <label className="field"><span>LOCATION <small>OPTIONAL</small></span><div className="field-with-icon"><MapPin size={15}/><input value={location} onChange={e => setLocation(e.target.value)} placeholder="Add a location"/></div></label>
              </div>
              <label className="field prompt-field"><span>WHAT DO YOU WANT TO DISCOVER?</span><textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows="3" placeholder="Describe what you want to understand..."/></label>
              <div className="prompt-suggestions"><span>TRY:</span><button onClick={() => setPrompt("Identify visible property features and potential maintenance concerns.")}>Condition review</button><button onClick={() => setPrompt("Find opportunities to improve visibility, access, and customer experience.")}>Opportunity scan</button><button onClick={() => setPrompt("Explore signage, branding, and exterior transformation possibilities.")}>Transformation ideas</button></div>
              <div className="panel-footer"><span><ShieldCheck size={14}/> Your materials stay in this local demo.</span><button className="primary-button" onClick={() => setStage("reveal")}>Begin discovery <ArrowRight size={16}/></button></div>
            </div>
          </div>
          <aside className="stage-aside">
            <div className="aside-orbit"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit-core"><Aperture size={31}/></div><span className="orbit-point p1"/><span className="orbit-point p2"/><span className="orbit-point p3"/></div>
            <div className="aside-copy"><div className="aside-overline">A DIFFERENT WAY OF SEEING</div><h3>Clarity begins<br/>with <em>curiosity.</em></h3><p>Start broad. Follow the evidence. Let the most meaningful insights emerge naturally.</p></div>
            <div className="aside-note"><span className="note-icon"><Focus size={16}/></span><div><strong>One canvas. A wider view.</strong><p>Images, context, findings, and next steps — connected in one continuous experience.</p></div></div>
          </aside>
        </section>}

        {stage === "reveal" && <section className="stage-layout work-layout">
          <div className="stage-main wide-main">
            <div className="section-kicker"><span>02</span> / REVEAL</div>
            <div className="work-heading"><div><h2>Look closer.<br/><em>See the signals.</em></h2><p className="stage-description">A visual reading of the scene, with evidence points to explore.</p></div><span className="demo-tag"><span/> ILLUSTRATIVE DEMO</span></div>
            <div className="evidence-workspace">
              <div className="evidence-toolbar"><div><span className="live-dot"/> VISUAL EVIDENCE CANVAS <small>· {assetName || "Untitled discovery"}</small></div><button className="tool-icon" onClick={() => notify("Canvas view controls are illustrative.")}><MoreHorizontal size={18}/></button></div>
              <div className="evidence-image">
                {fileUrl ? <div className="evidence-user-image" style={{backgroundImage:`url(${fileUrl})`}}/> : <SceneIllustration/>}
                <div className="image-vignette"/>
                <div className="image-coordinate">APERTURE / VISUAL SCAN / 001</div>
                {findings.map(f => <button key={f.id} className={`evidence-pin pin-${f.color} ${selectedFinding === f.id ? "pin-selected" : ""}`} style={{left:`${f.x}%`,top:`${f.y}%`}} onClick={() => setSelectedFinding(f.id)} aria-label={`View ${f.title}`}><span>{f.id}</span></button>)}
                <div className="image-scale"><span>FIELD OF VIEW</span><span>100%</span></div>
              </div>
              <div className="canvas-footer"><span><Scan size={14}/> {fileUrl ? "User-provided image" : "Illustrative commercial property scene"}</span><span>3 evidence markers <i/> Demo data</span></div>
            </div>
            <div className="evidence-list">
              <div className="list-heading"><div><span className="section-mini">OBSERVATIONS</span><h3>Signals worth exploring</h3></div><span className="count-pill">03 FOUND</span></div>
              {findings.map(f => <button key={f.id} className={`finding-row ${selectedFinding === f.id ? "finding-active" : ""}`} onClick={() => setSelectedFinding(f.id)}>
                <span className={`finding-index ${f.color}`}>0{f.id}</span><span className="finding-copy"><strong>{f.title}</strong><small>{f.type}</small></span><span className={`confidence ${f.confidence.toLowerCase()}`}>{f.confidence} confidence</span><ChevronRight size={16}/>
              </button>)}
            </div>
          </div>
          <aside className="insight-panel"><div className="panel-label"><Sparkles size={14}/> SELECTED SIGNAL</div><div className={`insight-number ${finding.color}`}>0{finding.id}</div><div className="insight-type">{finding.type}</div><h3>{finding.title}</h3><p>{finding.detail}</p><div className="confidence-block"><span>DEMO CONFIDENCE LABEL</span><strong>{finding.confidence}</strong><div className="confidence-track"><i style={{width:finding.confidence==="High"?"88%":"64%"}}/></div></div><div className="insight-disclaimer"><ShieldCheck size={15}/> This is a UI demonstration. Findings are illustrative, not generated from the uploaded image.</div><button className="text-action" onClick={() => setStage("envision")}>Explore this opportunity <ArrowRight size={15}/></button></aside>
        </section>}

        {stage === "envision" && <section className="stage-layout work-layout">
          <div className="stage-main wide-main">
            <div className="section-kicker"><span>03</span> / ENVISION</div>
            <h2>Imagine what<br/><em>could be.</em></h2>
            <p className="stage-description">Move from observation to possibility. Compare directions before committing to a plan.</p>
            <div className="concept-card">
              <div className="concept-visual">
                <div className="concept-before"><SceneIllustration/><span>OBSERVED SCENE</span></div>
                <div className="concept-after"><div className="concept-building"><div className="concept-sign">YOUR BRAND</div><div className="concept-windows"/></div><div className="concept-light"/></div>
                <div className="concept-divider" style={{left:`${compare}%`}}><span><ChevronLeft size={13}/><ChevronRight size={13}/></span></div>
                <input className="compare-range" type="range" min="10" max="90" value={compare} onChange={e=>setCompare(Number(e.target.value))} aria-label="Compare concept view"/>
                <span className="concept-label before-label">CURRENT</span><span className="concept-label after-label">POSSIBILITY</span>
              </div>
              <div className="concept-caption"><div><span className="concept-kicker">DIRECTION 01 · CONCEPT STUDY</span><h3>Make the first impression count.</h3><p>A conceptual direction for clearer identity, stronger visual hierarchy, and a more intentional arrival experience.</p></div><span className="concept-status">EXPLORATION</span></div>
            </div>
            <div className="concept-options"><button className="concept-option active"><span className="option-swatch swatch-one"/><span><strong>Identity & visibility</strong><small>Signage · brand presence</small></span><Check size={16}/></button><button className="concept-option" onClick={() => notify("Access & arrival concept selected for exploration.")}><span className="option-swatch swatch-two"/><span><strong>Access & arrival</strong><small>Wayfinding · experience</small></span><ArrowUpRight size={15}/></button><button className="concept-option" onClick={() => notify("Exterior refinement concept selected for exploration.")}><span className="option-swatch swatch-three"/><span><strong>Exterior refinement</strong><small>Materials · visual cohesion</small></span><ArrowUpRight size={15}/></button></div>
          </div>
          <aside className="insight-panel envision-aside"><div className="panel-label"><WandSparkles size={14}/> CREATIVE INTENT</div><h3>Possibility is a starting point.</h3><p>Use concept studies to align stakeholders around a direction. This preview is a stylized interface concept, not an AI-generated architectural rendering.</p><div className="aside-stat"><span>01</span><div><strong>Explore</strong><small>Surface possible directions</small></div></div><div className="aside-stat"><span>02</span><div><strong>Compare</strong><small>Understand the visual trade-offs</small></div></div><div className="aside-stat"><span>03</span><div><strong>Refine</strong><small>Prepare a brief for execution</small></div></div><button className="text-action" onClick={() => setStage("quantify")}>Understand the impact <ArrowRight size={15}/></button></aside>
        </section>}

        {stage === "quantify" && <section className="stage-layout work-layout">
          <div className="stage-main wide-main">
            <div className="section-kicker"><span>04</span> / QUANTIFY</div>
            <h2>Make the value<br/><em>understandable.</em></h2>
            <p className="stage-description">Frame the decisions, dependencies, and information needed before assigning a budget or forecast.</p>
            <div className="metrics-grid">
              <div className="metric-card"><span>OPPORTUNITY AREAS</span><strong>03</strong><small><span className="metric-dot cyan-dot"/> Areas identified for review</small></div>
              <div className="metric-card"><span>DECISION READINESS</span><strong>Early</strong><small><span className="metric-dot gold-dot"/> More evidence required</small></div>
              <div className="metric-card"><span>ESTIMATE STATUS</span><strong>Pending</strong><small><span className="metric-dot violet-dot"/> No verified cost data</small></div>
            </div>
            <div className="decision-card"><div className="decision-head"><div><span className="section-mini">DECISION FRAMEWORK</span><h3>What needs to be known next?</h3></div><span className="count-pill">3 WORKSTREAMS</span></div>
              {[["01","Site verification","Confirm dimensions, access, and existing conditions."],["02","Scope definition","Select the improvement direction and define deliverables."],["03","Commercial validation","Collect supplier pricing, labor assumptions, permits, and timelines."]].map(([n,t,d])=><div className="decision-row" key={n}><span>{n}</span><div><strong>{t}</strong><small>{d}</small></div><span className="pending-label">TO VALIDATE</span></div>)}
            </div>
            <div className="honesty-note"><ShieldCheck size={17}/><p><strong>Evidence before estimates.</strong> APERTURE should only present cost, valuation, or ROI figures when there is a traceable source, stated assumptions, and a clear confidence level. This prototype intentionally does not invent financial projections.</p></div>
          </div>
          <aside className="insight-panel"><div className="panel-label"><Target size={14}/> DECISION SIGNAL</div><div className="readiness-ring"><div><strong>01</strong><span>STAGE</span></div></div><h3>Build the evidence base.</h3><p>The next valuable step is not a speculative number. It is closing the information gaps that make a reliable estimate possible.</p><button className="text-action" onClick={() => setStage("activate")}>Build the action brief <ArrowRight size={15}/></button></aside>
        </section>}

        {stage === "activate" && <section className="stage-layout work-layout">
          <div className="stage-main wide-main">
            <div className="section-kicker"><span>05</span> / ACTIVATE</div>
            <h2>Turn insight<br/>into <em>momentum.</em></h2>
            <p className="stage-description">Bring the discovery together in a concise brief your team can review, refine, and put to work.</p>
            <div className="activation-card"><div className="activation-top"><div className="activation-icon"><Clipboard size={22}/></div><span className="demo-tag"><span/> READY TO REVIEW</span></div><div className="activation-kicker">APERTURE / INTELLIGENCE BRIEF</div><h3>{assetName || "Untitled discovery"}</h3><p className="activation-location"><MapPin size={14}/>{location || "Location not specified"}</p><div className="activation-divider"/><div className="brief-block"><span>DISCOVERY INTENT</span><p>{prompt}</p></div><div className="brief-block"><span>KEY AREAS TO EXPLORE</span><div className="brief-tags">{findings.map(f=><span key={f.id}>{f.title}</span>)}</div></div><div className="brief-block"><span>RECOMMENDED NEXT MOVES</span><ol><li>Validate the visual observations with on-site or source evidence.</li><li>Confirm scope and gather relevant technical requirements.</li><li>Request sourced pricing and timelines from qualified providers.</li></ol></div><div className="activation-actions"><button className="primary-button" onClick={downloadBrief}><Download size={16}/> Export intelligence brief</button><button className="outline-button" onClick={() => setStage("discover")}><Plus size={15}/> Start another discovery</button></div></div>
            <div className="closing-line"><Aperture size={17}/> <span>SEE BEYOND THE VISIBLE.</span><i/> <span>MOVE WITH CLARITY.</span></div>
          </div>
          <aside className="insight-panel"><div className="panel-label"><Zap size={14}/> NEXT CHAPTER</div><h3>From visual intelligence to real-world action.</h3><p>This is where APERTURE can connect to specialist workflows: property assessment, contractor scoping, insurance documentation, signage planning, and partner services.</p><div className="integration-list"><span><span className="integration-dot"/> Property & asset intelligence</span><span><span className="integration-dot"/> Contractor & supplier network</span><span><span className="integration-dot"/> Insurance & risk workflows</span><span><span className="integration-dot"/> Spatial & geospatial context</span></div><div className="integration-note">Future integrations · Not connected in this prototype</div></aside>
        </section>}

        <footer className="stage-footer"><button className="back-button" onClick={back} disabled={currentIndex===0}><ChevronLeft size={16}/> Back</button><div className="footer-center"><span>APERTURE</span><i/> VISUAL INTELLIGENCE / 2026</div>{currentIndex < 4 ? <button className="next-button" onClick={advance}>Continue to {stages[currentIndex+1].label} <ArrowRight size={16}/></button> : <button className="next-button" onClick={downloadBrief}>Export brief <Download size={15}/></button>}</footer>
      </div>
    </main>

    {showBrief && <div className="modal-backdrop" onClick={() => setShowBrief(false)}><div className="brief-modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><span className="section-mini">DISCOVERY OVERVIEW</span><h3>Intelligence brief</h3></div><button className="icon-button" onClick={() => setShowBrief(false)}><X size={18}/></button></div><p className="modal-asset">{assetName || "Untitled discovery"}</p><p className="modal-location"><MapPin size={14}/>{location || "Location not specified"}</p><div className="modal-progress">{stages.map((s,i)=><div key={s.id} className={i<=currentIndex?"modal-done":""}><span>{i<currentIndex?<Check size={11}/>:s.n}</span>{s.label}</div>)}</div><p className="modal-disclaimer">Prototype preview. Findings and concepts are illustrative demo content, not live analysis.</p><button className="primary-button full-button" onClick={() => {setShowBrief(false);downloadBrief();}}>Export brief <Download size={15}/></button></div></div>}
    {toast && <div className="toast"><Check size={15}/>{toast}</div>}
    <div className="demo-watermark">INTERACTIVE PROTOTYPE <span>·</span> DEMO MODE</div>
  </div>;
}

export default App;
