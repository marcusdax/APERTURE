# APERTURE — Visual Intelligence Prototype

A complete, responsive React/Vite front-end prototype for APERTURE, a visual intelligence product.

## Product experience

The prototype is organized as one progressive journey:

1. **Discover** — add an image, name the asset, set context, and describe the question.
2. **Reveal** — explore a visual evidence canvas and selectable observation markers.
3. **Envision** — compare a current scene with a conceptual direction using an interactive reveal slider.
4. **Quantify** — identify missing evidence and validation work before making cost or value claims.
5. **Activate** — assemble and export a concise intelligence brief.

## Run locally

Requirements: Node.js 18.18+ (Node 20 LTS recommended).

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (normally http://localhost:5173).

Production build:

```bash
npm run build
npm run preview
```

## Prototype functionality

- Responsive dark, hybrid workspace UI
- Interactive five-stage journey navigation
- Local image upload and preview (no upload server)
- Editable discovery name, location, and natural-language objective
- Prompt suggestion shortcuts
- Clickable evidence markers and finding details
- Before/possibility comparison slider
- Decision-readiness and validation framework
- Intelligence brief modal and downloadable `.txt` brief
- Toast feedback and mobile navigation
- Reduced-motion support

## Important: demo boundaries

This is a **front-end prototype**, not a connected AI product. Findings, confidence labels, concept imagery, and metrics are illustrative interface content. Uploaded images are previewed locally in the browser and are not analyzed, transmitted, or stored by a backend. No computer-vision inference, geospatial lookup, valuation, inspection, cost estimate, ROI calculation, authentication, or external integration is connected.

## Suggested production architecture

Keep the experience modular and connect real services behind explicit contracts:

- `POST /api/discoveries` — create a discovery and return an ID
- `POST /api/discoveries/:id/assets` — securely ingest image assets
- `POST /api/discoveries/:id/analyze` — enqueue multimodal/CV analysis
- `GET /api/discoveries/:id` — retrieve status, evidence, and provenance
- `POST /api/discoveries/:id/concepts` — generate and version concept studies
- `POST /api/discoveries/:id/briefs` — create an exportable evidence-backed brief

Recommended domain objects:

- `Discovery`: objective, subject, location, owner, status
- `Asset`: URI, media type, source, capture metadata, consent and retention policy
- `Observation`: label, geometry, confidence, evidence references, model/version
- `Opportunity`: rationale, dependencies, validation requirements, status
- `ConceptStudy`: direction, prompt, source assets, generated output, revision
- `Estimate`: line items, source, assumptions, validity window, confidence
- `Brief`: selected evidence, decisions, citations, export version

## Design principles

- Image-first, not dashboard-first.
- Progressive disclosure: reveal complexity only as the user advances.
- Evidence before assertion: distinguish observation, inference, concept, and verified fact.
- Confidence must be calibrated and traceable to evidence.
- Financial outputs require sourced inputs and explicit assumptions.
- Support keyboard navigation, semantic controls, sufficient contrast, and reduced motion in production hardening.

## Brand foundation

**APERTURE**  
*See beyond what is visible.*

Voice: perceptive, visionary, composed, and specific. Avoid generic AI hype. The product should describe what it can support, what remains uncertain, and what the user can do next.
